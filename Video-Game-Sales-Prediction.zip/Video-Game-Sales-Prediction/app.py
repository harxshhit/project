import streamlit as st
import numpy as np
import pickle
import streamlit.components.v1 as components
from sklearn.preprocessing import LabelEncoder
le = LabelEncoder()
# Load the pickled model
def load_model():
    return pickle.load(open('Sales_Prediction_LinearRegresssion.pkl', 'rb'))

# Function for model prediction
def model_prediction(model, features):
    predicted = str(model.predict(features)[0])
    return predicted

def transform(text):
    text = le.fit_transform(text)
    return text[0]

def app_design():
    # Add input fields for High, Open, and Low values
    
    st.image("42.png", use_container_width=True)
    
    st.subheader("Enter the following values:")

    #Encoding categorical data values
    
    Rank = st.number_input("Rank")

    Platform = st.text_input("Platform")
    Platform = transform([Platform])
    
    Year = st.number_input("Year")
    
    Genre = st.text_input("Genre")
    Genre = transform([Genre])

    Publisher = st.text_input("Publisher")
    Publisher = transform([Publisher])
    
    NA_Sales_up = st.number_input("NA Sales Up")
    
    EU_Sales_up = st.number_input("EU Sales Up")

    JP_Sales_up = st.number_input("JP Sales Up")
    
    Other_Sales_up = st.number_input("Other Sales Up")
 
    # Create a feature list from the user inputs
    features = [[Rank, Platform, Year, Genre, Publisher, NA_Sales_up, EU_Sales_up, JP_Sales_up, Other_Sales_up]]
    
    # Load the model
    model = load_model()
    
    # Make a prediction when the user clicks the "Predict" button
    if st.button('Predict Sale'):
        predicted_value = model_prediction(model, features)
        st.success(f"The Sale is: {predicted_value}")       


def about_hidevs():

        components.html("""
        <div>
      </div>
        """,
                    height=600)

def main():

        # Set the app title and add your website name and logo
        st.set_page_config(
        page_title="Video Game Sales Prediction",
        page_icon=":chart_with_upwards_trend:",
        )
    
        st.title("Welcome to our Video Game Sales Prediction Prediction App!")
    
        app_design()    
        st.header("")
        about_hidevs()

if __name__ == '__main__':
        main()
